//
//  KDNavigationController.h
//  cal
//
//  Created by hxx on 14-4-18.
//  Copyright (c) 2014年 hxx. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface KDNavigationController : UINavigationController

@end
